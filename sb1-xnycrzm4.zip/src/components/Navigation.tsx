import React from 'react';
import { NavLink } from 'react-router-dom';
import { BookHeart, Home, LineChart, MessageCircle, Users } from 'lucide-react';

export function Navigation() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 md:relative md:h-screen md:w-64 md:border-r md:border-t-0">
      <div className="flex justify-around md:flex-col md:space-y-6 md:mt-8">
        <NavItem to="/" icon={<Home />} label="Home" />
        <NavItem to="/journal" icon={<BookHeart />} label="Journal" />
        <NavItem to="/mood" icon={<LineChart />} label="Mood" />
        <NavItem to="/support" icon={<MessageCircle />} label="Support" />
        <NavItem to="/community" icon={<Users />} label="Community" />
      </div>
    </nav>
  );
}

function NavItem({ icon, label, to }: { icon: React.ReactNode; label: string; to: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex flex-col items-center p-2 rounded-lg transition-colors
        ${isActive ? 'text-purple-600 bg-purple-50' : 'text-gray-600 hover:bg-gray-50'}`
      }
    >
      {icon}
      <span className="text-sm mt-1">{label}</span>
    </NavLink>
  );
}