import React from 'react';
import { Bot } from 'lucide-react';

export function AIHeader() {
  return (
    <div className="p-4 border-b border-gray-100 flex items-center gap-2">
      <div className="p-2 bg-purple-100 rounded-lg">
        <Bot className="h-5 w-5 text-purple-600" />
      </div>
      <div>
        <h2 className="font-semibold text-gray-800">Luna</h2>
        <p className="text-sm text-gray-500">Your Personal AI Assistant</p>
      </div>
    </div>
  );
}