import React, { useState, useRef, useEffect } from 'react';
import { AIHeader } from './AIHeader';
import { AIMessage } from './AIMessage';
import { AIInput } from './AIInput';
import { generateAIResponse } from '../../utils/ai-responses';

interface Message {
  id: string;
  content: string;
  sender: 'ai' | 'user';
  timestamp: Date;
}

const INITIAL_MESSAGE: Message = {
  id: '1',
  content: "Hi, I'm Luna, your personal mental health assistant. How are you feeling today?",
  sender: 'ai',
  timestamp: new Date(),
};

export function PersonalAI() {
  const [messages, setMessages] = useState<Message[]>([INITIAL_MESSAGE]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    setTimeout(() => {
      const aiResponse = generateAIResponse(input);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        sender: 'ai',
        timestamp: new Date(),
      }]);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-xl shadow-sm border border-gray-100">
      <AIHeader />
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <AIMessage
            key={message.id}
            content={message.content}
            sender={message.sender}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <AIInput
        input={input}
        onInputChange={setInput}
        onSend={handleSend}
      />
    </div>
  );
}