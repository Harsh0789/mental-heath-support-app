import React from 'react';
import { Bot, User } from 'lucide-react';

interface AIMessageProps {
  content: string;
  sender: 'ai' | 'user';
}

export function AIMessage({ content, sender }: AIMessageProps) {
  return (
    <div className={`flex items-start gap-3 ${sender === 'user' ? 'flex-row-reverse' : ''}`}>
      <div className={`p-2 rounded-lg ${sender === 'ai' ? 'bg-purple-100' : 'bg-blue-100'}`}>
        {sender === 'ai' ? (
          <Bot className="h-5 w-5 text-purple-600" />
        ) : (
          <User className="h-5 w-5 text-blue-600" />
        )}
      </div>
      <div
        className={`rounded-lg p-3 max-w-[80%] ${
          sender === 'ai' ? 'bg-gray-100 text-gray-800' : 'bg-purple-600 text-white'
        }`}
      >
        {content}
      </div>
    </div>
  );
}