import React from 'react';
import { BookOpen, Headphones, MessageSquare, PenSquare } from 'lucide-react';

export function QuickActions() {
  const actions = [
    {
      icon: <Headphones className="h-6 w-6" />,
      title: "Meditate",
      description: "Start a guided session",
      gradient: "from-blue-500 to-blue-600"
    },
    {
      icon: <PenSquare className="h-6 w-6" />,
      title: "Journal",
      description: "Write your thoughts",
      gradient: "from-green-500 to-green-600"
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Chat Support",
      description: "Talk to someone",
      gradient: "from-purple-500 to-purple-600"
    },
    {
      icon: <BookOpen className="h-6 w-6" />,
      title: "Resources",
      description: "Learn more",
      gradient: "from-orange-500 to-orange-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {actions.map((action) => (
        <div key={action.title} className="gradient-border">
          <div className="bg-white p-6 rounded-xl card-3d h-full">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${action.gradient} 
              flex items-center justify-center text-white mb-3 floating`}>
              {action.icon}
            </div>
            <h3 className="font-semibold text-gray-800">{action.title}</h3>
            <p className="text-sm text-gray-600 mt-1">{action.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
}