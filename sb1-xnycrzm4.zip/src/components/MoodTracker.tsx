import React from 'react';
import { SmilePlus } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/Card';

export function MoodTracker() {
  const moods = [
    { emoji: '😊', label: 'Great', color: 'bg-green-100' },
    { emoji: '🙂', label: 'Good', color: 'bg-blue-100' },
    { emoji: '😐', label: 'Okay', color: 'bg-yellow-100' },
    { emoji: '😕', label: 'Down', color: 'bg-orange-100' },
    { emoji: '😢', label: 'Sad', color: 'bg-red-100' },
  ];

  return (
    <Card className="card-3d">
      <CardHeader>
        <CardTitle>How are you feeling?</CardTitle>
        <SmilePlus className="text-purple-600 h-6 w-6 floating" />
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-5 gap-2 sm:gap-4">
          {moods.map((mood) => (
            <button
              key={mood.label}
              className={`flex flex-col items-center space-y-2 rounded-xl p-3 transition-all
                duration-300 hover:scale-110 hover:shadow-lg ${mood.color}`}
            >
              <span className="text-2xl sm:text-3xl floating">{mood.emoji}</span>
              <span className="text-xs sm:text-sm text-gray-600 font-medium">{mood.label}</span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}