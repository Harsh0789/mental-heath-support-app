import React from 'react';
import { Lightbulb } from 'lucide-react';

export function DailyTip() {
  return (
    <div className="card-3d overflow-hidden">
      <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl p-6 text-white relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl transform translate-x-32 -translate-y-32" />
        <div className="relative z-10">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-white/20 rounded-lg floating">
              <Lightbulb className="h-6 w-6" />
            </div>
            <h2 className="text-xl font-semibold">Daily Wellness Tip</h2>
          </div>
          <p className="text-white/90">
            Take 5 minutes today to practice deep breathing. Find a quiet space, close your eyes, 
            and focus on your breath. This simple practice can help reduce stress and anxiety.
          </p>
          <button className="mt-4 glass-effect px-4 py-2 rounded-lg text-sm hover:bg-white/30 transition-colors">
            Try Now
          </button>
        </div>
      </div>
    </div>
  );
}