import React from 'react';
import { Outlet } from 'react-router-dom';
import { Navigation } from '../components/Navigation';
import { Container } from '../components/ui/Container';

export function MainLayout() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      <Navigation />
      <main className="flex-1 pb-24 md:pb-8">
        <Container className="py-8">
          <div className="max-w-4xl mx-auto">
            <Outlet />
          </div>
        </Container>
      </main>
    </div>
  );
}