import React from 'react';
import { PageHeader } from '../components/ui/PageHeader';
import { DailyTip } from '../components/DailyTip';
import { MoodTracker } from '../components/MoodTracker';
import { QuickActions } from '../components/QuickActions';

export function HomePage() {
  return (
    <div className="space-y-8">
      <PageHeader
        title="Welcome back, Sarah"
        description="Let's take care of your mental well-being today"
      />
      
      <div className="space-y-8">
        <DailyTip />
        <section className="space-y-6">
          <MoodTracker />
          <div className="mt-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
            <QuickActions />
          </div>
        </section>
      </div>
    </div>
  );
}