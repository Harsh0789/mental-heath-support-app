import React from 'react';
import { MessageSquare, Phone, Video } from 'lucide-react';
import { PersonalAI } from '../components/ai/PersonalAI';

export function SupportPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Support</h1>
        <p className="text-gray-600">Get help when you need it</p>
      </header>

      <div className="grid gap-6">
        <PersonalAI />

        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-4">
              <Video className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-800">Video Session</h2>
            </div>
            <p className="text-gray-600 mb-4">
              Schedule a video call with a licensed therapist.
            </p>
            <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
              Book Session
            </button>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-4">
              <Phone className="h-6 w-6 text-green-600" />
              <h2 className="text-xl font-semibold text-gray-800">Crisis Helpline</h2>
            </div>
            <p className="text-gray-600 mb-4">
              24/7 support for urgent mental health needs.
            </p>
            <button className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
              Call Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}