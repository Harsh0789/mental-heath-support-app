import React from 'react';
import { Users, MessageCircle, Heart } from 'lucide-react';

export function CommunityPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Community</h1>
        <p className="text-gray-600">Connect with others on similar journeys</p>
      </header>

      <div className="grid gap-4">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Discussion Groups</h2>
            <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
              New Post
            </button>
          </div>

          {[...Array(3)].map((_, i) => (
            <div key={i} className="border-b last:border-0 py-4">
              <div className="flex items-start gap-4">
                <div className="bg-purple-100 rounded-full p-3">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-800 mb-1">Anxiety Support Group</h3>
                  <p className="text-gray-600 text-sm mb-2">
                    Tips for managing anxiety during work presentations...
                  </p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-4 w-4" />
                      24 replies
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="h-4 w-4" />
                      15 likes
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}