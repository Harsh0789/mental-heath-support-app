import React from 'react';
import { PenSquare, Calendar } from 'lucide-react';

export function JournalPage() {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Journal</h1>
        <button className="bg-purple-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-purple-700">
          <PenSquare className="h-5 w-5" />
          <span>New Entry</span>
        </button>
      </header>

      <div className="grid gap-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <Calendar className="h-5 w-5 text-purple-600" />
              <span className="text-gray-600">March {15 - i}, 2024</span>
            </div>
            <p className="text-gray-800 line-clamp-3">
              Today was a productive day. I managed to complete several tasks that had been weighing on my mind...
            </p>
            <div className="mt-4 flex gap-2">
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">Reflection</span>
              <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Gratitude</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}