import React from 'react';
import { LineChart as LineChartIcon, Calendar } from 'lucide-react';

export function MoodPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Mood Tracker</h1>
        <p className="text-gray-600">Track and understand your emotional well-being</p>
      </header>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Mood History</h2>
          <div className="flex gap-2">
            <button className="px-3 py-1 text-sm border rounded-lg hover:bg-gray-50">Week</button>
            <button className="px-3 py-1 text-sm border rounded-lg bg-purple-50 text-purple-600 border-purple-200">Month</button>
          </div>
        </div>
        <div className="h-64 flex items-center justify-center border-b mb-4">
          <LineChartIcon className="h-32 w-32 text-gray-300" />
        </div>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Calendar className="h-5 w-5 text-gray-500" />
                <span>March {15 - i}, 2024</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">😊</span>
                <span className="text-gray-600">Great</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}