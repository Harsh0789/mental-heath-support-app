export interface Mood {
  id: string;
  date: Date;
  rating: number;
  notes: string;
}

export interface JournalEntry {
  id: string;
  date: Date;
  content: string;
  mood: number;
  tags: string[];
}

export interface MeditationSession {
  id: string;
  title: string;
  duration: number;
  category: string;
  description: string;
}