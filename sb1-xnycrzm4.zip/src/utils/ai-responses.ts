export function generateAIResponse(userInput: string): string {
  const lowercaseInput = userInput.toLowerCase();
  
  if (lowercaseInput.includes('anxious') || lowercaseInput.includes('anxiety')) {
    return "I understand that anxiety can be overwhelming. Let's try a quick breathing exercise: Breathe in for 4 counts, hold for 4, and exhale for 4. Would you like to try this together?";
  }
  
  if (lowercaseInput.includes('sad') || lowercaseInput.includes('depressed')) {
    return "I hear that you're feeling down. Remember that it's okay to feel this way, and you're not alone. Would you like to talk about what's troubling you or explore some mood-lifting activities together?";
  }
  
  if (lowercaseInput.includes('stress') || lowercaseInput.includes('overwhelmed')) {
    return "Being stressed can be really challenging. Let's break things down into smaller, manageable steps. What's the main thing causing you stress right now?";
  }
  
  return "I'm here to support you. Could you tell me more about what's on your mind?";
}